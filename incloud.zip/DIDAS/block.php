<?php
require_once "../INFINITE/Bussins.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accsess Closed</title>
    <script src="https://cdn.tondaar.ir/cdn/jquery/min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <style>

        html , body , div{
            font-family: "Open Sans";
            text-align: center;
            direction: ltr;

        }
    </style>
</head>
<body>
<div >
    <center>
        <div>
            <h1>Your Access To The Site Is Closed!</h1>
            <p>The INFINITE Request Management System Detects Your Requests To Enter The Site As Abnormal.</p>
            <p>This Analysis Is Based On Your IP And Your Behavior On The Site Pages.</p>
            <p>Your IP Is Closed Snd You Will Not Have Access To The Site For Another 24 Hours.  </p>
        </div>
        <div style="bottom: 0px;background-color: #87EFFB">
            <div style="text-align: center">
                <a>Your IP Address : <?php echo Bussins::GETIP()[3] ?></a>
                <a> | </a>
                <a>Server Time : <span style="text-align: left;direction: ltr"><?php echo  date('Y-m-d H:i:s') ?></span></a>
                <a> | </a>
                <a id="broswer_name"></a>
                <a> | </a>
                <a id="platform"></a>
            </div>
        </div>
        <div>
            <p> powered by <span style="color: darkred">EXPLORER INFINITE iNCloud</span> </p>
        </div>
    </center>
</div>

</body>
<script>
    var broswer_name = navigator.appCodeName ;
    var platform = navigator.platform;
    $("#broswer_name").html("Broswer  : "+broswer_name);
    $("#platform").html("Operation System : "+platform);
</script>
</html>