<?php
require_once "../INFINITE/Bussins.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>JavaScript Blocked | iNcloud</title>
    <script src="https://cdn.tondaar.ir/cdn/jquery/min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
    <style>
        html , body , div{
            font-family: "Open Sans";
            text-align: center;
            direction: ltr;

        }
    </style>
</head>
<body>
<div class="container">
    <div class="col-md-12">
        <h1>JavaScript On Your Broswer Blocked or Not Supported !</h1>
        <p>Please Turn On JavaScript On Your Broswer and If Your Broswer Not Supported JavaScript Download a New Broswer</p>
        <p>EXPLORER iNcloud</p>
    </div>

</div>
</body>

</html>