<?php


class Scripts
{
static function MESSAGE($MESSAGE){
    echo "<script>alert('$MESSAGE');</script>";

}

static function Redirect($Address){
    echo "<script>window.location = '$Address' </script>" ;
    return array('OK : EXPLORER INFINITE' , 1111 , true , true ) ;

}
static function LOG($TEXT){
    echo "<script>console.log($TEXT)</script>" ;
    return array('OK : EXPLORER INFINITE' , 1111 , true , true ) ;
}
static function GOBACK(){
    echo "<script>window.location.history.back();</script>";
}
    static function RELOAD(){
        echo "<script>window.location.reload();</script>" ;
    }
}

