<?php
session_start();
require_once "../../INFINITE/DataAccses.php";
require_once "../../INFINITE/Bussins.php";
$explorer_infinite_settings = DataAccses::FETCHITEM('incloud_settings' , '*' , "data_id = 1")[3];

date_default_timezone_set('Asia/Tehran');
function check_accses(){
    $ip = Bussins::GETIP()[3];
    $exist = DataAccses::ISEXIST('incloud_block' , array(array('ip' , '=',"$ip") ));
    if ($exist[2]==true){
        return "block";
    }
    else{
        return "ok";
    }
}
if (!empty($_POST['create_client'])){
    require_once '../../SYSTEM_LIB/device.php';
    $broswer_name = $_POST['broswer_name'];
    $broswer_height = $_POST['broswer_height'] ;
    $broswer_width = $_POST['broswer_width'] ;
    $load_time = $_POST['load_time'] ;
    $ip = Bussins::GETIP()[3];
    $page_url = $_POST['page'] ;
    $referer = $_SESSION['referer'] ;
    $device = "";
    $platform = $_POST['platform'] ;
    $agent = $_SERVER['HTTP_USER_AGENT'] ;
    $now_time = time();
    $live_time = 1 ;
    $detect = new Mobile_Detect;
    if ($detect->isMobile()){
        $device = "Mobile";
    }
    elseif ($detect->isTablet()){
        $device = "Tablet";
    }
    else{
        $device = "PC";
    }

    if (isset($_SESSION['client_id'])){
        $client_id = $_SESSION['client_id'];
    }
    else{
        $client_id = DataAccses::FETCHITEM('incloud_visits' , '*' , "client_id != 0 ORDER BY client_id DESC")[3]['client_id']+1;
        $_SESSION['client_id'] = $client_id;
    }
    $_SESSION['referer'] = $page_url;
    $parametrs = array('client_id' , 'start_live' , 'end_live' , 'live_time' , 'page_url' , 'broswer_name' , 'agent' , 'platform' , 'device' , 'referer' , 'ip' , 'scroll_status' , 'screen_height' , 'screen_width' , 'load_time' );
    $values = array($client_id, "$now_time" , "$now_time" , $live_time , "$page_url" , "$broswer_name" , "$agent" , "$platform" , "$device" , "$referer" , "$ip" , 0 , $broswer_height , $broswer_width , $load_time  );
    $add_info = DataAccses::INSERT('incloud_visits'  , $parametrs , $values);
    $data_id = DataAccses::FETCHITEM('incloud_visits' , '*' , "id != 0 ORDER BY id DESC")[3]['id'];
    $_SESSION['data_id'] = $data_id;
    echo "ok";


}
if (!empty($_POST['keep_live'])){
    $broswer_height = $_POST['broswer_height'] ;
    $broswer_width = $_POST['broswer_width'] ;
    $ip = Bussins::GETIP()[3];
    $now_time = time();
    $live_time = $_POST['live_time'] ;
    $client_id = $_SESSION['client_id'];
    $data_id = $_SESSION['data_id'];
    $update_info = DataAccses::UPDATE('incloud_visits', "end_live = '$now_time' , live_time = $live_time , ip = '$ip' , screen_height = $broswer_height , screen_width = $broswer_width" , "id = $data_id");
    echo $data_id;
}
if (!empty($_POST['getting'])){
    $url = $_POST['url'] ;
    $time = date('Y-m-d H:i:s');;
    $ip = Bussins::GETIP()[3];
    $exist = DataAccses::ISEXIST('incloud_block' , array(array('ip' , '=',"$ip") ));
    $broswer_name = $_POST['broswer_name'];
    $width = $_POST['width'];
    $height = $_POST['height'] ;
    $platform = $_POST['system_platform'] ;
    if ($exist[2]==true){
        $block_time = $exist[3]['expierd'] ;
        if ((strtotime($time) - strtotime($block_time)<0)){
            $block_id = $exist[3]['block_id'];
            DataAccses::DELETE('incloud_block' , "block_id = $block_id");
            echo 'ok';
            $after_activs = 1;
        }
        else{
            echo 'block';
            $after_activs = 0;
        }
    }
    else{
        DataAccses::INSERT('incloud_logs' , array('time' , 'ip' , 'url' , 'platform' , 'broswer_name' , 'width' , 'height' ) , array("$time" , "$ip" , "$url" , "$platform" , "$broswer_name" ,$width , $height ));
        $log_with_this_ip = DataAccses::SELECT('incloud_logs' , '*' , "ip = '$ip'")[3];
        $over_head_ip_log = 0;
        $this_url_ip_over_head = 0 ;
        foreach ($log_with_this_ip as $log){
            $log_time = $log['time'] ;
            $log_url = $log['url'];
            if ((strtotime($time) - strtotime($log_time)<3)){
                $over_head_ip_log++;
                if ($log_url==$url){
                    $this_url_ip_over_head++;
                }
            }

        }
        if ($over_head_ip_log>$explorer_infinite_settings['request_max']&&($this_url_ip_over_head/$over_head_ip_log)>0.7){
            $block_time = strtotime("tomorrow");
            $after_activs = 0;
            DataAccses::INSERT('incloud_block' , array('time' , 'ip' , 'expierd') , array("$time" , "$ip" , "$block_time"));
            echo  'block';
        }
        else{
            $after_activs = 1;
            echo 'ok';
        }
    }
}
