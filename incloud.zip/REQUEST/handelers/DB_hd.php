<?php
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";

if (!empty($_POST['db_query'])){

    $function = $_POST['run_function'] ;
    $respone = "";
    if ($function=="SELECT"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'] ;
        $condition = $_POST['condition'] ;
        if (group_null_empty(array($table_name , $item_select , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECT($table_name , $item_select , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="INSERT"){
        $table_name = $_POST['table'] ;
        $parametrs = explode(' |-|-| ' , $_POST['parametrs']);
        $values = explode(' |-|-| ' , $_POST['values']);
        if (group_null_empty(array($table_name , $parametrs , $values))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::INSERT($table_name , $parametrs , $values);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="QUERY"){
        $query = $_POST['query'];
        if (null_empty($query)==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::QUERY($query);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="DELETE"){
        $table_name = $_POST['table'] ;
        $condition = $_POST['condition'] ;
        if(group_null_empty($table_name , $condition)==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::DELETE($table_name , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="UPDATE"){
        $table_name = $_POST['table'] ;
        $set_values = $_POST['set'] ;
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $set_values , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::UPDATE($table_name , $set_values , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="SELECTITEM"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $index = $_POST['index'] ;
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $item_select , $index , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECTITEM($table_name , $item_select , $index, $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="SELECTITEMS"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $index = $_POST['index'] ;
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $item_select , $index , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECTITEM($table_name , $item_select , $index, $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="FETCHITEM"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $item_select , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::FETCHITEM($table_name , $item_select , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="SELECTONE"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $condition = $_POST['condition'];
        $index = $_POST['index'] ;
        if (group_null_empty(array($table_name , $item_select , $condition , $index))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECTONE($table_name , $item_select , $index ,  $condition );
            $respone = create_respone($result);
        }
    }
    elseif ($function=="ISEXIST"){
        $table_name = $_POST['table'];
        $conditions = $_POST['conditions'];
        if (group_null_empty(array($table_name , $conditions))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $conditions = explode(' |--| ' , $conditions);
            $condition_array = array();
            foreach ($conditions as $condition){
                $condition_parts = explode(' -*- ' , $conditions );
                array_push($condition_array , $condition_parts);
            }
            $result = DataAccses::ISEXIST($table_name , $condition_array);
            $respone = create_respone($result);
        }

    }
    echo $respone;

}
