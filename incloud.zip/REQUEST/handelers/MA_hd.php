<?php
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";
if (!empty($_POST['manual'])){
    $code = $_POST['code'];
    $requier_s = explode(' |split_requier| ' , $_POST['requiers']);
    $respone = "";
    $requier_text = "" ;
    $random_number = rand(100000 , 999999);
    $file_name = "../../TEMP/run_function_$random_number.php";
    foreach ($requier_s as $requier_){
        $requier_text.= "include '../../$requier_' ; ";
    }
    $file = fopen($file_name , 'w');
    fwrite($file , "<?php $requier_text function run(){".$code."}");
    fclose($file);
    include $file_name;
    $result = run();
    unlink($file_name);
    $respone = create_respone($result);
    echo $respone;
}