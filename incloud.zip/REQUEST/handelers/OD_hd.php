<?php
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";
if (!empty($_POST['other'])){
    $function = $_POST['run_function'];
    $respone = "";
    if ($function=="server_time"){
        $format = $_POST['format'] ;
        $result = date($format);
    }
    elseif ($function=="mkdir"){
        $dir_name = $_POST['dir_name'];
        $result = mkdir("../../../".$dir_name);
    }
    elseif ($function=="create_file"){
        $method = $_POST['method'] ;
        $content = $_POST['content'] ;
        $file_name = $_POST['file_name'];
        $stream_file = fopen($file_name , $method);
        fwrite($stream_file , $content);
        fclose($stream_file);
        $result="ok";
    }
    elseif ($function=="remove_file"){
        $file_name = $_POST['file_name'];
        unlink($file_name);
        $result = "ok";
    }


}