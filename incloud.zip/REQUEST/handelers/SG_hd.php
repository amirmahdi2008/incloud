<?php
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";

if (!empty($_POST['super_global'])){
    $variable = $_POST['variable'] ;
    $action = $_POST['action'];
    $result = "";
    $respone = "";
    if ($action=="all"){
        if ($variable=="get"){
            $result = $_GET;
        }
        elseif ($variable=="post"){
            $result = $_POST;
        }
        elseif ($variable=="session"){
            $result = $_SESSION;
        }
        elseif ($variable=="files"){
            $result = $_FILES;
        }
        elseif ($variable=="server"){
            $result = $_SERVER;
        }
        elseif ($variable=="request"){
            $result = $_REQUEST;
        }
        elseif ($variable=="cookie"){
            $result = $_COOKIE;
        }
        elseif ($variable=="env"){
            $result = $_ENV;
        }
    }
    elseif ($action=="item"){
        $index = $_POST['index'];
        if ($variable=="get"){
            $result = $_GET[$index];
        }
        elseif ($variable=="post"){
            $result = $_POST[$index];
        }
        elseif ($variable=="session"){
            $result = $_SESSION[$index];
        }
        elseif ($variable=="files"){
            $result = $_FILES[$index];
        }
        elseif ($variable=="server"){
            $result = $_SERVER[$index];
        }
        elseif ($variable=="request"){
            $result = $_REQUEST[$index];
        }
        elseif ($variable=="cookie"){
            $result = $_COOKIE[$index];
        }
        elseif ($variable=="env"){
            $result = $_ENV[$index];
        }
    }
    elseif ($action=="change"){
        $value = $_POST['value'];
        $index = $_POST['index'];
        if ($variable=="session"){
            $_SESSION[$index] = $value;
            $result = "ok";
        }
        elseif ($variable=="cookie"){
            $_COOKIE[$index] = $value;
            $result = "ok";
        }

    }
    elseif ($action="insert"){
        $value = $_POST['value'] ;
        $cookie_name = $_POST['name'] ;
        $expire = $_POST['expire'];
        $path = $_POST['path'] ;
        setcookie($cookie_name , $value , $expire , $path);
        $result = "ok";
    }
    $respone=create_respone($result);
    echo $respone;
}
