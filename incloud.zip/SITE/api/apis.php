<?php
require_once "../../INFINITE/allpath.php";
require_once "../../SYSTEM_LIB/security.php";
//Write Your API Codes Here