<?php
include "../../INFINITE/allpath.php";
$action = $_GET['ac'];
if ($action=="file"){
    $file_id = $_GET['id'];
    $file = DataAccses::FETCHITEM('incloud_files' , '*' , "id = $file_id")[3];
    $url = $file['url'];
    if (file_exists("../".$url)){

        header('Content-Description: File Transfer');
        header('Content-Type:application/octet-stream');
        header('Content-Disposition: attachment;filename="'.basename($url).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma:public');
        header('Content-Length:'.filesize($url));
        readfile($url);
        exit;
    }
}