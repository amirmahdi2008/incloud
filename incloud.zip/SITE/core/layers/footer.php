<?php
// you can edit this file . footer of your site set by this function
function get_footer(){
    ?>
        <footer>
            <div class="col-md-12">
                <center>
                    <p>All Rights Reserved For EXPLORER iNcloud !</p>
                    <p>Created By iNcloud</p>
                </center>
            </div>
        </footer>
    </body>
    </html>
<?php
}