<?php
// you can edit this functon . header of your site set by this function
function get_header($page_title ){
    ?>
    <!DOCTYPE html>
    <html lang="fa">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $page_title ?></title>
        <link rel="stylesheet" href="https://cdn.tondaar.ir/cdn/bootstrap/5.1.3/css/min.css">
        <script src="https://cdn.tondaar.ir/cdn/jquery/min.js"></script>
        <script src="static/js/incloud.min.js"></script>
        <script src="static/js/script.js"></script>
        <script src="static/js/date.min.js"></script>
        <link rel="stylesheet" href="static/css/style.css">
        <link rel="icon" href="static/images/branding/logo.png">
    </head>


    <noscript>
        <iframe width="100%" height="100%" src="../DIDAS/nojs.php"></iframe>
    </noscript>
    <body style="direction: rtl;text-align: right;font-family: Dana">
    <header id="header" >


    </header>
    <div id="document">
<?php
}
    
