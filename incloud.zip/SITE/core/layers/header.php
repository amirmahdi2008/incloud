<?php
// you can edit this functon . header of your site set by this function
function get_header($page_title ){
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $page_title ?></title>
        <div style="width: 100%;background-color: lightgrey;position: fixed;top: 0px;">
            <div id="loading_progress_incloud" style="background-color: #F68F0D;width: 0%;height: 4px;"></div>
        </div>
        <script>var loaded=0;function incloud_loading_progress(d){"fade"==d?(loaded+=.5,document.getElementById("loading_progress_incloud").style.width=loaded+"%",100==loaded&&(loaded=0)):document.getElementById("loading_progress_incloud").style.width="0%"}function incloud_loading(d){setInterval(function(){incloud_loading_progress(d)},100)}</script>
        <link rel="stylesheet" href="https://cdn.tondaar.ir/cdn/bootstrap/5.1.3/css/min.css">
        <script src="https://cdn.tondaar.ir/cdn/jquery/min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
        <script src="static/js/incloud.min.js"></script>
        <script src="static/js/script.js"></script>
        <link rel="stylesheet" href="static/css/style.css">
        <style>
            html , body , div {font-family: "Open Sans";}
        </style>

    </head>

    <noscript>
        <iframe width="100" height="100" src="../DIDAS/nojs.php"></iframe>
    </noscript>
    <body>
    <header>
        <div class="container">
            <div class="col-md-12">
                <div  class="col-md-6"><a style="text-decoration: none" href="index.php"><h3>EXPLORER iNcloud</h3></a></div>
            </div>
        </div>

    </header>
<?php
}
    
