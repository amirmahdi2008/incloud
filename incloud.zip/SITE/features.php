<?php
include "requiers.php";
get_requiers();
get_header("features of iNcloud ");
?>
<div class="container">
    <div class="col-md-12">
        <h1>EXPLORER iNcloud Features !</h1>
        <h4>DataBase Queries</h4>
        <a>SELECT From Data Base</a><br>
        <a>INSERT To Data Base</a><br>
        <a>DELETE To Data Base</a><br>
        <a>UPDATE Records in Data Base</a><br>
        <a>FETCHITEM in INFINITE</a><br>
        <a>SELECTONE in INFINITE</a><br>
        <a>ISEXIST in INFINITE</a><br>
        <a>QUERY in INFINITE</a><br>
        <a>SELECTITEM in INFINITE</a><br>
        <a>SELECTITEMS in INFINITE</a><hr>
        <h4>Super Globals</h4><br>
        <a>SESSION (change , get , get_all)</a><br>
        <a>COOKIE (insert , change , get , get_all )</a><br>
        <a>GET ( get , get_all )</a><br>
        <a>POST (get , get_all)</a><br>
        <a>ENV (get , get_all)</a><br>
        <a>SERVER (get , get_all ) </a><br>
        <a>FILES (get , get_all )</a><br>
        <a>REQUEST (get , get_all )</a><hr>
        <h4>Other Functions </h4><br>
        <a>Create Folder (mkdir)</a><br>
        <a>Create File (fopen , fwrite , fclose)</a><br>
        <a>Remove File (unlink)</a><br>
        <a>Server Time (time)</a><hr>
        <h4>Client Tools</h4><br>
        <a>Turn Off Right Click </a><br>
        <a>Change Website Protocol </a><br>
        <a>Create broswer Object to use broswer data</a><br>
        <a>Use Page Loaders </a><br>
        <h4>Reporting </h4><br>
        <a>Send Visitor Information (broswer , device , clicks , stay_time , screen size , ip , ...)</a><hr>
        <h4>Security </h4><br>
        <a>Didas Manager & Found Didas and Block ip(s)</a><br>
    </div>
</div>
