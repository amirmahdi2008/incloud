<?php
function get_requiers(){
    include "../INFINITE/allpath.php";
    include "core/layers/header.php";
    include "core/layers/footer.php";
}
