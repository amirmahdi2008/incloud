import your images to this folder
import logo(s) and branding images to branding folder at this folder