// here write general scripts
