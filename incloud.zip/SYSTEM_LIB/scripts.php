<?php
function null_empty($value){
    if ($value==""||$value==null){
        return false;
    }
    else{
        return true;
    }
}
function group_null_empty($values){
    $res = true;
    foreach ($values as $value){
        if (null_empty($value)==false){
            $res=false;
        }
    }
    return $res;
}
function create_respone($result  ){
    if (is_array($result)){
        $all = array();
        foreach ($result as $res){

            if (is_array($res)){
                if (is_array($res[0])){
                    foreach ($res as $re){
                        array_push($all , implode(' |in_array| ' , $re));

                    }
                }
                else{
                    array_push($all , implode(' |in_array| ' , $res));
                }
            }
            else{
                array_push($all , $res);
            }

        }
        $respone = implode(' |item_spliter| ' , $all);
    }
    else{
        $respone = $result;
    }
    return $respone ;

}