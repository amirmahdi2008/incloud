<?php
$referer = $_SERVER['HTTP_REFERER'];
$parse_url = parse_url($referer);
$host_url = $_SERVER['HTTP_HOST'];
if ($parse_url['host']!=$host_url){
    echo "Request Is Not Valid ! By EXPLORER iNcloud";
}

