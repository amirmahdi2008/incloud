<?php
$requested_url = $_SERVER['REQUEST_URI'];
$run_time = time();
$ip = Bussins::GETIP()[3];
$client_id = 0 ;
if (isset($_SESSION['client_id'])){$client_id=$_SESSION['client_id'];}
DataAccses::INSERT('incloud_query' , array('run_time' , 'request_address' , 'ip' , 'client_id') , array("$run_time" , "$requested_url" , "$ip" , $client_id));
