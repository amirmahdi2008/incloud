<?php
echo "<a href='SITE/index.php'>Redirecting to https://oflink.ir/SITE</a>";
//echo "<script>window.location = 'SITE/'</script>";
?>
