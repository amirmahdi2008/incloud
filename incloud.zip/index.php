<?php
echo "<script>window.location = 'SITE/'</script>";
