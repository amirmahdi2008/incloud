<?php
/**
*In the name of god 
*iNcloud 1.2
*EXPLORER Open Source Projects Licence
*In The Name Of Allah
*You are using a free and open source software package.
*You should always follow the do's and don'ts of this software package according to EXPLORER Open Source Projects.
*You can change this open source software to your liking and make your desired version with changes.
*You can publish this software or introduce it to others.
*You can also publish an edited version of this software.
*If you have edited this software or had an edited version of it (third party version: a version that was not released to the public by the original publisher of the software and was edited by a third party) you must Be sure to mention that this released version is a third-party version of this software and its accuracy, health, and correct operation without error and with its security has not been approved by the original publisher.
*If you are using a third party version, you should keep in mind that the possibility of errors and malfunctions and the correct operation and security of this version is not guaranteed.
*You have no right to sell this open source software (although the software undergoes changes and is considered a third party version, in any case you have no right to sell this software.
*/
// you can edit this functon . header of your site set by this function
function get_header($page_title ){
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $page_title ?></title>
        <script>var loaded=0,interval="";function start_loading(e){"fade"==e?interval=setInterval(function(){page_loader("fade")},100):page_loader("fadeout")}function page_loader(e){"fade"==e?(loaded+=.5,document.getElementById("incloud_loading").style.width=loaded+"%",100==loaded&&(loaded=0)):document.getElementById("incloud_loading").style.width="0%"}</script>
        <link rel="stylesheet" href="https://cdn.tondaar.ir/cdn/bootstrap/5.1.3/css/min.css">
        <script src="https://cdn.tondaar.ir/cdn/jquery/min.js"></script>
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
        <script src="static/js/incloud.min.js"></script>
        <script src="static/js/incloud_controlers.js"></script>
        <script src="static/js/script.js"></script>
        <link rel="stylesheet" href="static/css/style.css">
        <style>
            html , body , div {font-family: "Open Sans";}
        </style>
    </head>
    <noscript>
        <iframe id="incloud_noscript_iframe" width="100" height="100" src="DIDAS/nojs.php"></iframe>
    </noscript>
    <body style="display: none">
    <header id="incloud_header">
        <div class="container">
            <div class="col-md-12">
                <div  class="col-md-6"><a style="text-decoration: none" href="index.php"><h3>EXPLORER iNcloud</h3></a></div>
            </div>
        </div>
        <div style="width: 100%;background-color: lightgrey;position: fixed;top: 0px;">
            <div id="incloud_loading" style="background-color: #F68F0D;width: 0%;height: 4px;"></div>
        </div>
    </header>
    <div id="incloud_container">
<?php
}
    
