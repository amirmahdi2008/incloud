<?php
/**
*In the name of god 
*iNcloud 1.2
*EXPLORER Open Source Projects Licence
*In The Name Of Allah
*You are using a free and open source software package.
*You should always follow the do's and don'ts of this software package according to EXPLORER Open Source Projects.
*You can change this open source software to your liking and make your desired version with changes.
*You can publish this software or introduce it to others.
*You can also publish an edited version of this software.
*If you have edited this software or had an edited version of it (third party version: a version that was not released to the public by the original publisher of the software and was edited by a third party) you must Be sure to mention that this released version is a third-party version of this software and its accuracy, health, and correct operation without error and with its security has not been approved by the original publisher.
*If you are using a third party version, you should keep in mind that the possibility of errors and malfunctions and the correct operation and security of this version is not guaranteed.
*You have no right to sell this open source software (although the software undergoes changes and is considered a third party version, in any case you have no right to sell this software.
*/


// you can call requiers.php file to requier all files you need to requier . you can edit requier.php file content
include "requiers.php";
// this function requier all files that you need to requier . for calling this function , first you include requiers.php file
get_requiers();
// this function call header file . you can write title of page for set page title
get_header("Hello World !");

// <html> <head> <body> <header> called in get_header() . you write content you need to write
?>

    <div class="col-md-12">
        <div class="container">
            <h1>Hello World !</h1>
            <h4>This is First Page With EXPLORER iNcloud !</h4>
            <p><strong>You Can Write & Edit Pages ! </strong></p>
            <p>Please Wait ! i am interducing iNcloud to you ! </p>
        </div>

    </div>
    <div class="col-md-12">
        <div class="container">
            <div class="col-md-12">
                <div class="col-md-6">
                    <div class="col-md-12" id="messages"></div>
                </div>
                <div class="col-md-6" id="run_php_code">
                    <div class="col-md-12">
                        <span>Code Requiers</span>
                        <textarea class="form-control" id="requiers" rows="2" placeholder="Write Requier Files Here"></textarea><br>
                        <span>php Code</span>
                        <textarea  class="form-control" id="code" rows="5" placeholder="Write php Codes here"></textarea><br>
                        <button onclick="run()" class="btn btn-primary">Run !</button>
                        <br>
                    </div>
                    <div class="col-md-12" id="result"></div>
                </div>
            </div>

            <div class="col-md-12">
                <div class="col-md-6" id="signup">
                    <span>Please Enter Your Name </span>
                    <input type="text" class="form-control" id="Name">
                    <span>Please Enter Your Family</span>
                    <input type="text" class="form-control" id="Family">
                    <button class="btn btn-primary" onclick="join()">Join</button>
                </div>
            </div>
        </div>
    </div>
<div class="col-md-12">
    <div class="container">
        <a href="features.php"><h3>See All Fetures of iNcloud</h3></a>
    </div>
</div>
    <script>
        var Person_Name = "";
        var Person_Family = "";
        // here there is messages you read ( messages added to data base and read from data base and show you ! )
        // this function add messages to data base . only 1 line !
        function insert_new_messages(text){INSERT('messages' , ['text' ] , [text] , vars={use_loader:"not_use",use_function:function (){}});}
        var message_number = 0;
        //interval for set messages text and call function for insert to data base
        setInterval(function (){
            if (message_number==0){insert_new_messages("Hello ! i am iNcloud !");}
            else if(message_number==1){insert_new_messages("i am here for helping you in creating a site");}
            else if(message_number==3){insert_new_messages("you can connect to data base with javascript !! also control super global variables in client ! ");}
            else if(message_number==4){insert_new_messages("Load Pages with very small size and show your content with AJAX !");}
            else if(message_number==5) {insert_new_messages("Esay and  Fast for all !");}
            else if (message_number==6){insert_new_messages("You do not know how to use iNcloud ?");}
            else if (message_number==7){insert_new_messages("i am here !");}
            else if (message_number==8){insert_new_messages("you can try samples in this page to interducing EXPLORER iNcloud !");}
            message_number++;} , 2000);
        // this function select new unread messages to show you . Messages after loading changed readed column to 1 (Read)
        function load_new_messages(){incloud_SELECT('messages' , '*' , "readed = 0" , vars={use_loader: 'not_use' , use_function:show_new_messages});}
        // this function show new messages to you
        function show_new_messages(data){
            if (data.length==4 && data[3]==""){
                console.log("There Is No New Messages !");
            }
            else{
                data = incloud_REMOVE_STATIC_DATA(data);
                data = incloud_preper_uniq_column(data , 'nested' , 0);
                for (message in data){
                    message = data[message];
                    $("#messages").append("<div class='alert alert-success'>"+message[0]+"</div><br>");
                    var id = message[4];
                    // this function update showed messages
                    incloud_UPDATE('messages' ,  "readed = 1" , "id = "+id , vars={use_loader:'not_use' , use_function:function (data){}} );
                }
            }
        }
        //interval for select new messages from data base and show to you
        setInterval(load_new_messages , 2500);
        //end of creating and load messages
        // run manual php code in server and show result to you
        function run(){
            var requiers = $("#requiers").val();
            var code = $("#code").val();
            // this function run code to server and return result to passed function
            incloud_php_code(code , requiers.split(" , ") , vars={use_loader:'use' , use_function:function (data){$("#result").append(data);}});
        }
        // end of run manual code in server
        //this function get person_id value in data base for registered user and set session
        function set_session(session){SESSION('change' , ['person_id' , session] , vars={use_loader:'not_use' , use_function:function (){$("#signup").append("<div class='alert alert-success'><p>You Are Regestered Mr. "+Person_Name+" "+Person_Family+" </p></div>")}});}
        function joined(){FETCHITEM('users' , '*' , "person_id != 0 ORDER BY person_id DESC" , vars={use_loader:"use" , use_function:function (data){data=REMOVE_STATIC_DATA(data);data =preper_uniq_column(data , 'nested' , 0);set_session(data[3][6]);}});}
        //this function insert person data in data base
        function join(){
            Person_Name = $("#Name").val();
            Person_Family = $("#Family").val();
            incloud_INSERT('users' , ['first_name' , 'last_name'] , [Person_Name , Person_Family ] , vars={use_loader:'use' , use_function:function (data){alert('You Joined !');$("#Name").val("");$("#Family").val("");joined()}});
        }
    </script>

<?php
// with calling this function footer of site setting up . closed tags ( </html> </body> </footer> )
get_footer();