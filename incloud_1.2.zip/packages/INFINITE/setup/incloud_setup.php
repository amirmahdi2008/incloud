<?php
/**
*In the name of god 
*iNcloud 1.2
*EXPLORER Open Source Projects Licence
*In The Name Of Allah
*You are using a free and open source software package.
*You should always follow the do's and don'ts of this software package according to EXPLORER Open Source Projects.
*You can change this open source software to your liking and make your desired version with changes.
*You can publish this software or introduce it to others.
*You can also publish an edited version of this software.
*If you have edited this software or had an edited version of it (third party version: a version that was not released to the public by the original publisher of the software and was edited by a third party) you must Be sure to mention that this released version is a third-party version of this software and its accuracy, health, and correct operation without error and with its security has not been approved by the original publisher.
*If you are using a third party version, you should keep in mind that the possibility of errors and malfunctions and the correct operation and security of this version is not guaranteed.
*You have no right to sell this open source software (although the software undergoes changes and is considered a third party version, in any case you have no right to sell this software.
*/


if (isset($_GET['setup_db'])){
    $DatabaseName = $_GET['db_name'];
    $DatabaseUsername = $_GET['db_username'];
    $DatabasePassword = $_GET['db_password'];
    $Account_Username = $_GET['account_username'] ;
    $Account_Password = $_GET['account_password'] ;
    $Account_Name = $_GET['account_name'] ;
    $Max_Allow_Reques = $_GET['max_request'];
    $myfile = fopen("../DatabaseDB.php", "w") or die("Unable to open file!");
    $txt = '<?php ';
    fwrite($myfile, $txt);
    $txt = "class DatabaseDB { ";
    fwrite($myfile, $txt);
    $txt = 'static function Connect(){ ';
    fwrite($myfile, $txt);
    $txt = '$DatabaseName = ' . "'" . $DatabaseName . "' ; ";
    fwrite($myfile, $txt);
    $txt = '$Username = ' . "'" . $DatabaseUsername . "' ; ";
    fwrite($myfile, $txt);
    $txt = '$Password = ' . "'" . $DatabasePassword . "' ; ";
    fwrite($myfile, $txt);
    $txt = 'return array($DatabaseName , $Username , $Password) ; ';
    fwrite($myfile, $txt);
    $txt = "}";
    fwrite($myfile, $txt);
    fwrite($myfile, $txt);
    fclose($myfile);
    include "../DataAccses.php";
    $result = DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`incloud_block` ( `time` VARCHAR(50) NULL , `expierd` VARCHAR(100) NULL , `ip` VARCHAR(50) NULL , `block_id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`block_id`)) ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci COMMENT = 'SAVE BLOCKS OF iNcloud';");
    DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`incloud_logs` ( `time` VARCHAR(50) NULL , `ip` VARCHAR(50) NULL , `url` TEXT NULL , `platform` VARCHAR(200) NULL , `broswer_name` VARCHAR(100) NULL , `width` INT NULL , `height` INT NULL , `log_id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`log_id`)) ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci COMMENT = 'SAVE LOGS OF iNcloud';");
    DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`incloud_query` ( `run_time` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP , `request_address` VARCHAR(400) NULL , `ip` VARCHAR(50) NULL , `client_id` INT NULL , `id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci COMMENT = 'SAVE QUIERIES OF iNcloud';");
    DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`incloud_settings` ( `request_max` INT NULL , `username` VARCHAR(100) NULL , `password` VARCHAR(100) NULL , `person_name` VARCHAR(100) NULL , `data_id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`data_id`)) ENGINE = InnoDB COMMENT = 'SAVE SETTINGS OF iNcloud';");
    DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`incloud_visits` ( `client_id` INT NULL , `start_live` VARCHAR(50) NULL , `end_live` VARCHAR(50) NULL , `live_time` INT NULL , `page_url` TEXT NULL , `broswer_name` VARCHAR(50) NULL , `agent` VARCHAR(200) NULL , `platform` VARCHAR(50) NULL , `device` VARCHAR(50) NULL , `referer` TEXT NULL , `ip` VARCHAR(50) NULL , `scroll_status` INT NULL , `screen_height` INT NULL , `screen_width` INT NULL , `load_time` INT NULL , `id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci COMMENT = 'SAVE VISITS OF iNcloud';");
    DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`messages` ( `text` VARCHAR(400) NULL , `readed` INT NOT NULL DEFAULT '0' , `id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`id`)) ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci COMMENT = 'SAVE MESSAGES OF LANDING . YOU CAN REMOVE THIS TABLE ';");
    DataAccses::QUERY("CREATE TABLE `$DatabaseName`.`users` ( `first_name` VARCHAR(100) NULL , `last_name` VARCHAR(100) NULL , `time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP , `person_id` INT NOT NULL AUTO_INCREMENT , PRIMARY KEY (`person_id`)) ENGINE = InnoDB CHARSET=utf8 COLLATE utf8_general_ci COMMENT = 'SAVE USERS FOR LANDING . YOU CAN REMOVE THIS TABLE';");

    $result =DataAccses::INSERT('incloud_settings' , array('request_max' , 'username' , 'password' , 'person_name' , 'data_id') , array($Max_Allow_Reques , "$Account_Username" , "$Account_Password" , "$Account_Name" , 1));

    if ($result[1]==317){
        echo "not_ok";
    }
    else{
        echo "ok";
    }
}