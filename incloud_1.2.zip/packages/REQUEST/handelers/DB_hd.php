<?php
/**
*In the name of god 
*iNcloud 1.2
*EXPLORER Open Source Projects Licence
*In The Name Of Allah
*You are using a free and open source software package.
*You should always follow the do's and don'ts of this software package according to EXPLORER Open Source Projects.
*You can change this open source software to your liking and make your desired version with changes.
*You can publish this software or introduce it to others.
*You can also publish an edited version of this software.
*If you have edited this software or had an edited version of it (third party version: a version that was not released to the public by the original publisher of the software and was edited by a third party) you must Be sure to mention that this released version is a third-party version of this software and its accuracy, health, and correct operation without error and with its security has not been approved by the original publisher.
*If you are using a third party version, you should keep in mind that the possibility of errors and malfunctions and the correct operation and security of this version is not guaranteed.
*You have no right to sell this open source software (although the software undergoes changes and is considered a third party version, in any case you have no right to sell this software.
*/
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";

if (!empty($_POST['db_query'])){

    $function = $_POST['run_function'] ;
    $respone = "";
    if ($function=="SELECT"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'] ;
        $condition = $_POST['condition'] ;
        if (group_null_empty(array($table_name , $item_select , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECT($table_name , $item_select , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="INSERT"){
        $table_name = $_POST['table'] ;
        $parametrs = explode(' |-|-| ' , $_POST['parametrs']);
        $values = explode(' |-|-| ' , $_POST['values']);
        if (group_null_empty(array($table_name , $parametrs , $values))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::INSERT($table_name , $parametrs , $values);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="QUERY"){
        $query = $_POST['query'];
        if (null_empty($query)==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::QUERY($query);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="DELETE"){
        $table_name = $_POST['table'] ;
        $condition = $_POST['condition'] ;
        if(group_null_empty($table_name , $condition)==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::DELETE($table_name , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="UPDATE"){
        $table_name = $_POST['table'] ;
        $set_values = $_POST['set'] ;
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $set_values , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::UPDATE($table_name , $set_values , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="SELECTITEM"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $index = $_POST['index'] ;
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $item_select , $index , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECTITEM($table_name , $item_select , $index, $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="SELECTITEMS"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $index = $_POST['index'] ;
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $item_select , $index , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECTITEM($table_name , $item_select , $index, $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="FETCHITEM"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $condition = $_POST['condition'];
        if (group_null_empty(array($table_name , $item_select , $condition))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::FETCHITEM($table_name , $item_select , $condition);
            $respone = create_respone($result);
        }
    }
    elseif ($function=="SELECTONE"){
        $table_name = $_POST['table'];
        $item_select = $_POST['select_items'];
        $condition = $_POST['condition'];
        $index = $_POST['index'] ;
        if (group_null_empty(array($table_name , $item_select , $condition , $index))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $result = DataAccses::SELECTONE($table_name , $item_select , $index ,  $condition );
            $respone = create_respone($result);
        }
    }
    elseif ($function=="ISEXIST"){
        $table_name = $_POST['table'];
        $conditions = $_POST['conditions'];
        if (group_null_empty(array($table_name , $conditions))==false){
            $respone = "ERROR : PARA NULL : 601";
        }
        else{
            $conditions = explode(' |--| ' , $conditions);
            $condition_array = array();
            foreach ($conditions as $condition){
                $condition_parts = explode(' -*- ' , $conditions );
                array_push($condition_array , $condition_parts);
            }
            $result = DataAccses::ISEXIST($table_name , $condition_array);
            $respone = create_respone($result);
        }

    }
    echo $respone;

}
