<?php
/**
*In the name of god 
*iNcloud 1.2
*EXPLORER Open Source Projects Licence
*In The Name Of Allah
*You are using a free and open source software package.
*You should always follow the do's and don'ts of this software package according to EXPLORER Open Source Projects.
*You can change this open source software to your liking and make your desired version with changes.
*You can publish this software or introduce it to others.
*You can also publish an edited version of this software.
*If you have edited this software or had an edited version of it (third party version: a version that was not released to the public by the original publisher of the software and was edited by a third party) you must Be sure to mention that this released version is a third-party version of this software and its accuracy, health, and correct operation without error and with its security has not been approved by the original publisher.
*If you are using a third party version, you should keep in mind that the possibility of errors and malfunctions and the correct operation and security of this version is not guaranteed.
*You have no right to sell this open source software (although the software undergoes changes and is considered a third party version, in any case you have no right to sell this software.
*/
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";
if (!empty($_POST['manual'])){
    $code = $_POST['code'];
    $requier_s = explode(' |split_requier| ' , $_POST['requiers']);
    $respone = "";
    $requier_text = "" ;
    $random_number = rand(100000 , 999999);
    $file_name = "../../TEMP/run_function_$random_number.php";
    foreach ($requier_s as $requier_){
        $requier_text.= "include '../../$requier_' ; ";
    }
    $file = fopen($file_name , 'w');
    fwrite($file , "<?php $requier_text function run(){".$code."}");
    fclose($file);
    include $file_name;
    $result = run();
    unlink($file_name);
    $respone = create_respone($result);
    echo $respone;
}