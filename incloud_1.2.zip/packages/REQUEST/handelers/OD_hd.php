<?php
/**
*In the name of god 
*iNcloud 1.2
*EXPLORER Open Source Projects Licence
*In The Name Of Allah
*You are using a free and open source software package.
*You should always follow the do's and don'ts of this software package according to EXPLORER Open Source Projects.
*You can change this open source software to your liking and make your desired version with changes.
*You can publish this software or introduce it to others.
*You can also publish an edited version of this software.
*If you have edited this software or had an edited version of it (third party version: a version that was not released to the public by the original publisher of the software and was edited by a third party) you must Be sure to mention that this released version is a third-party version of this software and its accuracy, health, and correct operation without error and with its security has not been approved by the original publisher.
*If you are using a third party version, you should keep in mind that the possibility of errors and malfunctions and the correct operation and security of this version is not guaranteed.
*You have no right to sell this open source software (although the software undergoes changes and is considered a third party version, in any case you have no right to sell this software.
*/
session_start();
include "../../INFINITE/allpath.php";
include "../../SYSTEM_LIB/scripts.php";
include "../../SYSTEM_LIB/security.php";
if (!empty($_POST['other'])){
    $function = $_POST['run_function'];
    $respone = "";
    if ($function=="server_time"){
        $format = $_POST['format'] ;
        $result = date($format);
    }
    elseif ($function=="mkdir"){
        $dir_name = $_POST['dir_name'];
        $result = mkdir("../../../".$dir_name);
    }
    elseif ($function=="create_file"){
        $method = $_POST['method'] ;
        $content = $_POST['content'] ;
        $file_name = $_POST['file_name'];
        $stream_file = fopen($file_name , $method);
        fwrite($stream_file , $content);
        fclose($stream_file);
        $result="ok";
    }
    elseif ($function=="remove_file"){
        $file_name = $_POST['file_name'];
        unlink($file_name);
        $result = "ok";
    }


}